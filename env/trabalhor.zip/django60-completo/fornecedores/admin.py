from django.contrib import admin
from .models import Fornecedores
# Register your models here.
admin.site.register(Fornecedores)