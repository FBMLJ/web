from django.apps import AppConfig


class FornecedoresConfig(AppConfig):
    name = 'fornecedores'
