from django.apps import AppConfig


class AutenticacaoConfig(AppConfig):
    name = 'autenticacao'
