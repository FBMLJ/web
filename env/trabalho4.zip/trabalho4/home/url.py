from django.urls import path

from . import views

app_name = "home"


urlpatterns = [
    path("", views.home, name="home"),
    path("faleConosco", views.faleConosco, name="faleConosco"),

    path("loja", views.loja, name="loja"),

    path("sobre", views.sobre, name="sobre")
    # path('admin/', admin.site.urls),
    
]