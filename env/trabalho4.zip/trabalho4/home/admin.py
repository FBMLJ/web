from django.contrib import admin

# Register your models here.
from .models import Passeio
from .models import Imagem
from .models import Destaque

from .models import Loja


admin.site.register(Passeio)
admin.site.register(Imagem)
admin.site.register(Destaque)
 
admin.site.register(Loja)