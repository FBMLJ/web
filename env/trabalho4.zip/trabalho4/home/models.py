from django.db import models

# Create your models here.
class Passeio(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    created = models.DateTimeField(auto_now_add=True)  
    updated = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
    
class Imagem(models.Model):
    page = models.CharField(max_length=50)
    slide = models.BooleanField()
    active = models.CharField( max_length=50)
    src = models.CharField( max_length=50)

    def __str__(self):
        return self.src
    
class Destaque(models.Model):
    text = models.TextField()
    src = models.CharField(max_length=50)
    title = models.CharField( max_length=50)

class Loja(models.Model):
    preco=  models.FloatField()
    nome = models.CharField(max_length=50)
    src = models.CharField(max_length=50)