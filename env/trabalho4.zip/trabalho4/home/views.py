# from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from .models import Imagem
from .models import Destaque

from .models import Loja

def home(request):
    slides = Imagem.objects.filter(page='home', slide=True)
    destaques = Destaque.objects.all()
    print(destaques)
    return render(request, 'home/home.html',{'isHome': 'active','slides': slides,  'destaques': destaques})

def faleConosco(request):
    img = Imagem.objects.get(page='faleConosco')
    return render(request,'home/faleConosco.html',{'isFaleConosco': 'active', 'img': img})

def loja(request):
    loja = Loja.objects.all()
    return render(request, 'home/loja.html',{'isLoja': 'active', 'loja': loja})

def sobre(request):
    img = Imagem.objects.get(page='sobre')
    return render(request, 'home/sobre.html', {'isSobre': 'active','img': img})